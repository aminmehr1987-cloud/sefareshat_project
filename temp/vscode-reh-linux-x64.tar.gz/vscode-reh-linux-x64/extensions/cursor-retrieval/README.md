# Cursor Retrieval

**Notice:** This extension is bundled with Visual Studio Code. It can be disabled but not uninstalled.

Implements logic for indexing a codebase and retrieving from it.
