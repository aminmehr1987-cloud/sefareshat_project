# Service to Scrub Sensitive Data Locally in Cursor

**Notice:** This extension is bundled with Cursor. It can be disabled but not uninstalled.

## Features

This is an internal feature of Cursor
