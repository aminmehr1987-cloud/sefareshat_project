# Cursor Always Local

- meant for always local work. This includes but is not limited to:
    1. cpp background work.
		2. node-local requets.
		3. long-term more stable streaming.
- please keep this light and __never__ do anything here that can rely on the file system. it wont work on ssh!!
